<?php
/**
 * Created by PhpStorm.
 * User: LANGANFIN  Rogelio
 * Date: 28/04/2021
 * Time: 09:51
 */

namespace App\Twig;

use App\Repository\NotificationRepository;
use Twig\Extension\AbstractExtension;
use Twig\TwigFunction;

class NotificationExtension  extends AbstractExtension
{

    /**
     * @var NotificationRepository
     */
    private $notificationRepository;

    public function __construct(NotificationRepository $notificationRepository)
    {
        $this->notificationRepository = $notificationRepository;
    }

    public function getFunctions()
    {
        return [
            new TwigFunction('get_notifications', [$this, 'getNotifications']),
        ];
    }

    public function getNotifications()
    {
        return $this->notificationRepository->findBy([], ['id' => 'DESC'], 4, null);
    }

}