<?php
/**
 * Created by PhpStorm.
 * User: LANGANFIN  Rogelio
 * Date: 28/04/2021
 * Time: 10:02
 */

namespace App\Service;


use App\Entity\User;
use Doctrine\ORM\EntityManagerInterface;

class UserService
{

    /**
     * @var EntityManagerInterface
     */
    private $entityManager;

    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    public function setNewOrganisationAdmin(User $user)
    {

        try {
            $organisation = $user->getOrganisation();
            $organisationUsers = $organisation->getuser()->getValues();


            foreach ($organisationUsers as $organisationUser) {
                $organisationUser->setIsOrganisationAdmin(false);
            }

            $user->setIsOrganisationAdmin(true);

            return "ok";
        } catch (\Exception $exception) {

        }

//        $this->entityManager->persist($notif);

    }

}