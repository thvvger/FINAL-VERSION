<?php
/**
 * Created by PhpStorm.
 * User: LANGANFIN Rogelio
 * Date: 06/09/2021
 * Time: 06:33
 */

namespace App\Service;


class ConstantClass
{
    const  validated_libelle = "Validé";
    const  rejected_libelle = "Rejeté";
    const  pending_libelle = "Rejeté";
    const  validated = "validated";
    const  rejected = "rejeted";
    const  pending = "pending";
}