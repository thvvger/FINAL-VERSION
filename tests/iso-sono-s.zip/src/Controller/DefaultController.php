<?php

namespace App\Controller;

use App\Repository\AnnonceRepository;
use App\Repository\AnnonceSonoriseRepository;
use App\Repository\UserRepository;
use App\Service\AnnonceService;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;


class DefaultController extends AbstractController
{


    /**
     * @var UserRepository
     */
    private $userRepository;
    /**
     * @var AnnonceSonoriseRepository
     */
    private $annonceSonoriseRepository;
    /**
     * @var AnnonceRepository
     */
    private $annonceRepository;

    public function __construct(UserRepository            $userRepository,
                                AnnonceSonoriseRepository $annonceSonoriseRepository,
                                AnnonceRepository         $annonceRepository)
    {
        $this->userRepository = $userRepository;
        $this->annonceSonoriseRepository = $annonceSonoriseRepository;
        $this->annonceRepository = $annonceRepository;
    }

    /**
     * @Route("/", name="dashboard")
     */
    public function index( AnnonceService $annonceService): Response
    {
        $user =  $this->getUser();
//            $anon = $this->annonceRepository->findBy(["estValider" => true], null, 5);
//        $annonceSonorise = $this->annonceSonoriseRepository->findOneBy(['annonce' => $anon[0]]);

//        dump($annonceSonorise->getApiAnnonceStats());
//        die;
//        return $this->render('default/index.html.twig', [
        $organisation = $user->getOrganisation();
        return $this->render('dashboard.html.twig', [
            'lastUsers' => $this->userRepository->findBy(['is_active' => true], null, 5),
            'lastAnnonces' => $this->annonceRepository->findBy(["deleted" => false ,'organisation'=> $organisation], null,100),
            'lastSonorisations' => $this->annonceSonoriseRepository->getLatest($organisation),
            'lastSonorisationsValidated' => $this->annonceSonoriseRepository->getLatestValide($organisation),
            'lastSonorisationsRejected' => $this->annonceSonoriseRepository->getLatestRejete($organisation),
        ]);
    }

    /**
     * @Route("/sonoriser", name="sonoriser")
     */
    public function sonoriser(Request $request)
    {
        if ($request->isMethod('POST')) {
            $this->addFlash("success", 'Enregistrement réussi  ');
            return $this->redirectToRoute('sonoriser');
        }
        return $this->render('deletable/sonorisation.html.twig', [
            'controller_name' => 'DefaultController',
        ]);
    }
}
